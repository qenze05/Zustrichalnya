package task.mohyla.zustrichalnya.users;

public class User {
    public String uid, username, profileImage;

    public User(String uid, String username, String profileImage) {
        this.uid = uid;
        this.username = username;
        this.profileImage = profileImage;
    }
}
