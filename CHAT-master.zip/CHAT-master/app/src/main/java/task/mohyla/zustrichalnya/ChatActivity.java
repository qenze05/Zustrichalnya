package task.mohyla.zustrichalnya;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import task.mohyla.zustrichalnya.databinding.ActivityChatBinding;
import task.mohyla.zustrichalnya.message.Message;
import task.mohyla.zustrichalnya.message.MessagesAdapter;

public class ChatActivity extends AppCompatActivity {

    private ActivityChatBinding binding;
    private String chatId;
    private String currentUserId;
    private String receiverUserId; // ID користувача, з яким проводиться чат
    private String receiverUserName; // Ім'я користувача, з яким проводиться чат

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        chatId = getIntent().getStringExtra("chatId");
        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Отримання receiverUserId з бази даних чату
        loadChatInfo();

        binding.sendMessageBtn.setOnClickListener(v -> {
            String message = binding.messageEt.getText().toString();
            if (message.isEmpty()){
                Toast.makeText(this, "Message field cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            String date = simpleDateFormat.format(new Date());

            binding.messageEt.setText(""); // очищення текстового поля
            sendMessage(message, date);
        });
    }

    private void loadChatInfo() {
        if (chatId == null) {
            Toast.makeText(this, "Error: Chat ID is null", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Отримання даних чату з бази даних
        FirebaseDatabase.getInstance().getReference().child("Chats").child(chatId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // Отримання даних про учасників чату
                            String user1Id = dataSnapshot.child("user1").getValue(String.class);
                            String user2Id = dataSnapshot.child("user2").getValue(String.class);

                            // Визначення receiverUserId на основі інформації про учасників чату
                            if (user1Id != null && !user1Id.equals(currentUserId)) {
                                receiverUserId = user1Id;
                            } else if (user2Id != null && !user2Id.equals(currentUserId)) {
                                receiverUserId = user2Id;
                            } else {
                                Toast.makeText(ChatActivity.this, "Error: Could not determine receiver user ID", Toast.LENGTH_SHORT).show();
                                finish();
                                return;
                            }

                            // Завантаження інформації про отримувача чату
                            loadReceiverUserInfo();
                            // Завантаження повідомлень чату
                            loadMessages();
                        } else {
                            Toast.makeText(ChatActivity.this, "Error: Chat does not exist", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(ChatActivity.this, "Error: Failed to load chat info", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }

    private void loadReceiverUserInfo() {
        if (receiverUserId == null) return;

        // Отримання інформації про отримувача з бази даних
        FirebaseDatabase.getInstance().getReference().child("Users").child(receiverUserId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            receiverUserName = dataSnapshot.child("username").getValue(String.class);
                            if (receiverUserName != null) {
                                binding.userNameTv.setText(receiverUserName);
                            }

                            String profileImageUrl = dataSnapshot.child("profileImage").getValue(String.class);
                            if (profileImageUrl != null && !profileImageUrl.isEmpty()) {
                                // Використовуйте вашу бібліотеку для завантаження фото, наприклад, Glide або Picasso
                                Glide.with(ChatActivity.this)
                                        .load(profileImageUrl)
                                        .placeholder(R.drawable.username_icon) // placeholder, якщо фото ще не завантажено
                                        .into(binding.profileIv);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Обробка помилок при зчитуванні даних з Firebase
                    }
                });
    }


    private void sendMessage(String message, String date) {
        if (chatId == null || receiverUserId == null) return;

        // Збереження повідомлення в базі даних
        HashMap<String, Object> messageInfo = new HashMap<>();
        messageInfo.put("text", message);
        messageInfo.put("ownerId", currentUserId);
        messageInfo.put("date", date);

        FirebaseDatabase.getInstance().getReference().child("Chats").child(chatId)
                .child("messages").push().setValue(messageInfo);
    }

    private void loadMessages() {
        if (chatId == null) return;

        // Завантаження повідомлень з бази даних
        FirebaseDatabase.getInstance().getReference().child("Chats")
                .child(chatId).child("messages").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists()) return;

                        List<Message> messages = new ArrayList<>();
                        for (DataSnapshot messageSnapshot : snapshot.getChildren()) {
                            String messageId = messageSnapshot.getKey();
                            String ownerId = messageSnapshot.child("ownerId").getValue(String.class);
                            String text = messageSnapshot.child("text").getValue(String.class);
                            String date = messageSnapshot.child("date").getValue(String.class);

                            messages.add(new Message(messageId, ownerId, text, date));
                        }

                        binding.messagesRv.setLayoutManager(new LinearLayoutManager(ChatActivity.this));
                        binding.messagesRv.setAdapter(new MessagesAdapter(messages));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(ChatActivity.this, "Failed to load messages", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
